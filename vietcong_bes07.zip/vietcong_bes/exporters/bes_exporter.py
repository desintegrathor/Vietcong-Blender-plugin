# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2024 Vietcong Blender Tools Contributors

"""
BES Exporter

Main export function that converts Blender scene to BES format.
"""

import os
import bpy
from mathutils import Vector
from typing import Dict, List, Optional, Set

from ..core.bes_writer import write_bes_file
from ..core.bes_types import (
    BESFile,
    BESHeader,
    BESPreview,
    BESInfo,
    BESNode,
    BESMesh,
    BESVertex,
    BESFace,
    BESTransform,
    BESMaterial,
    BESPteroMat,
    BESTexture,
    BESProperties,
    calculate_name_hash,
)
from ..core.constants import (
    BES_MAGIC,
    BES_VERSION_8,
    EXPORTER_BLENDER,
    TransparencyType,
    NO_MATERIAL,
    COLLISION_PREFIXES,
    SPECIAL_PREFIXES,
)
from ..utils.math_utils import (
    blender_to_bes_coords,
    blender_to_bes_uv,
    blender_to_bes_rotation,
    blender_to_bes_scale,
    calculate_bounding_sphere_radius,
)


def export_bes(context, filepath: str, **options) -> set:
    """Export Blender scene to BES file.

    Args:
        context: Blender context
        filepath: Output file path
        **options: Export options
            - export_selected: Export only selected objects
            - generate_preview: Generate preview image

    Returns:
        {'FINISHED'} on success, {'CANCELLED'} on failure
    """
    try:
        exporter = BESExporter(context, filepath, options)
        exporter.export()
        return {'FINISHED'}

    except Exception as e:
        print(f"BES Export Error: {e}")
        import traceback
        traceback.print_exc()
        return {'CANCELLED'}


class BESExporter:
    """Blender to BES exporter."""

    def __init__(self, context, filepath: str, options: dict):
        """Initialize exporter.

        Args:
            context: Blender context
            filepath: Output file path
            options: Export options
        """
        self.context = context
        self.filepath = filepath
        self.options = options

        # Material mapping: Blender material -> BES index
        self._material_indices: Dict[bpy.types.Material, int] = {}
        self._materials: List[BESMaterial] = []

        # Objects to export
        self._objects: List[bpy.types.Object] = []

    def export(self):
        """Export the scene to BES file."""
        # Gather objects to export
        self._gather_objects()

        # Collect and create materials
        self._collect_materials()

        # Build BES file structure
        bes_file = self._build_bes_file()

        # Write to file
        write_bes_file(self.filepath, bes_file)

        print(f"Exported BES file: {self.filepath}")

    def _gather_objects(self):
        """Gather objects to export."""
        if self.options.get('export_selected', False):
            self._objects = [obj for obj in self.context.selected_objects
                           if obj.type == 'MESH' or obj.type == 'EMPTY']
        else:
            self._objects = [obj for obj in self.context.scene.objects
                           if obj.type == 'MESH' or obj.type == 'EMPTY']

        # Filter to root objects (no parent or parent not in list)
        root_objects = []
        for obj in self._objects:
            if obj.parent is None or obj.parent not in self._objects:
                root_objects.append(obj)

        self._objects = root_objects

    def _collect_materials(self):
        """Collect all materials from objects to export."""
        materials_set: Set[bpy.types.Material] = set()

        for obj in self._objects:
            self._collect_materials_recursive(obj, materials_set)

        # Create BES materials
        for mat in materials_set:
            bes_mat = self._create_bes_material(mat)
            self._material_indices[mat] = len(self._materials)
            self._materials.append(bes_mat)

    def _collect_materials_recursive(self, obj: bpy.types.Object, materials_set: Set):
        """Recursively collect materials from object hierarchy."""
        if obj.type == 'MESH' and obj.data:
            for mat in obj.data.materials:
                if mat:
                    materials_set.add(mat)

        for child in obj.children:
            if child in self._objects or child.type == 'MESH':
                self._collect_materials_recursive(child, materials_set)

    def _create_bes_material(self, mat: bpy.types.Material) -> BESMaterial:
        """Create BES material from Blender material.

        Args:
            mat: Blender material

        Returns:
            BES material

        Properties exported from IDA analysis of BesExport.dlu:
        - faceted: Flat shading (from bes_faceted custom property)
        - grow_type, grass_type: Vegetation types
        - Material colors: diffuse, ambient, specular, self-illumination
        - Material properties: opacity, glossiness, spec_level
        - Water properties: env_blend, alpha_angle, sharpness, shifting
        """
        # Check if this was originally a BES material
        mat_type = mat.get('bes_material_type', 'pteromat')

        if mat_type == 'pteromat':
            bes_mat = BESPteroMat(
                name=mat.name,
                index=len(self._materials),
                two_sided=mat.get('bes_two_sided', not mat.use_backface_culling),
                faceted=mat.get('bes_faceted', False),
                collision_material=mat.get('bes_collision_material', ''),
                surface=mat.get('bes_surface', ''),
                transparency_type=mat.get('bes_transparency_type', TransparencyType.OPAQUE),
                grow_type=mat.get('bes_grow_type', ''),
                grass_type=mat.get('bes_grass_type', ''),
            )

            # Material colors from Blender material or custom properties
            if mat.use_nodes:
                # Try to get colors from Principled BSDF node
                base_color = self._get_principled_color(mat, 'Base Color')
                if base_color:
                    bes_mat.mat_diffuse = base_color[:3]

            # Override with custom properties if present
            if 'bes_mat_diffuse' in mat:
                bes_mat.mat_diffuse = tuple(mat['bes_mat_diffuse'])
            if 'bes_mat_ambient' in mat:
                bes_mat.mat_ambient = tuple(mat['bes_mat_ambient'])
            if 'bes_mat_specular' in mat:
                bes_mat.mat_specular = tuple(mat['bes_mat_specular'])
            if 'bes_mat_self_illum' in mat:
                bes_mat.mat_self_illum = tuple(mat['bes_mat_self_illum'])

            # Material properties
            bes_mat.mat_opacity = mat.get('bes_mat_opacity', 100)
            bes_mat.mat_opacity_falloff = mat.get('bes_mat_opacity_falloff', 0.0)
            bes_mat.mat_glossiness = mat.get('bes_mat_glossiness', 0)
            bes_mat.mat_spec_level = mat.get('bes_mat_spec_level', 0)

            # Shader properties
            bes_mat.shader_type_name = mat.get('bes_shader_type_name', '')
            bes_mat.shader_filename = mat.get('bes_shader_filename', '')

            # Water/glass properties
            bes_mat.is_water = mat.get('bes_is_water', False)
            bes_mat.is_glass = mat.get('bes_is_glass', False)
            bes_mat.water_env_blend = mat.get('bes_water_env_blend', 0.0)
            bes_mat.water_alpha_angle = mat.get('bes_water_alpha_angle', 0.0)
            if 'bes_water_sharpness' in mat:
                bes_mat.water_sharpness = tuple(mat['bes_water_sharpness'])
            if 'bes_water_shifting_xy' in mat:
                bes_mat.water_shifting_xy = tuple(mat['bes_water_shifting_xy'])
            if 'bes_water_shifting_uv' in mat:
                bes_mat.water_shifting_uv = tuple(mat['bes_water_shifting_uv'])

            # Find diffuse texture from shader nodes
            if mat.use_nodes:
                diffuse_tex = self._find_diffuse_texture(mat)
                if diffuse_tex:
                    bes_mat.textures['diffuse_1'] = BESTexture(
                        filename=diffuse_tex,
                        u_tile=True,
                        v_tile=True,
                    )
                    bes_mat.texture_flags |= 0x010000  # DIFFUSE_1 flag

            return bes_mat

        else:
            # Standard material (for compatibility)
            from ..core.bes_types import BESStandardMaterial
            bes_mat = BESStandardMaterial(
                name=mat.name,
                index=len(self._materials),
            )

            if mat.use_nodes:
                diffuse_tex = self._find_diffuse_texture(mat)
                if diffuse_tex:
                    bes_mat.textures['diffuse'] = BESTexture(
                        filename=diffuse_tex,
                        u_tile=True,
                        v_tile=True,
                    )
                    bes_mat.map_flags |= 0x001  # DIFFUSE flag

            return bes_mat

    def _find_diffuse_texture(self, mat: bpy.types.Material) -> Optional[str]:
        """Find diffuse texture filename from material nodes.

        Args:
            mat: Blender material

        Returns:
            Texture filename or None
        """
        if not mat.use_nodes:
            return None

        for node in mat.node_tree.nodes:
            if node.type == 'TEX_IMAGE' and node.image:
                # Get filename from image path
                filepath = node.image.filepath
                if filepath:
                    return os.path.basename(filepath)
                elif node.image.name:
                    return node.image.name

        return None

    def _get_principled_color(self, mat: bpy.types.Material, input_name: str) -> Optional[tuple]:
        """Get color value from Principled BSDF node input.

        Args:
            mat: Blender material
            input_name: Name of the input (e.g., 'Base Color', 'Emission')

        Returns:
            Color as tuple (R, G, B, A) or None
        """
        if not mat.use_nodes:
            return None

        for node in mat.node_tree.nodes:
            if node.type == 'BSDF_PRINCIPLED':
                if input_name in node.inputs:
                    input_socket = node.inputs[input_name]
                    if hasattr(input_socket, 'default_value'):
                        return tuple(input_socket.default_value)
        return None

    def _build_bes_file(self) -> BESFile:
        """Build complete BES file structure.

        Returns:
            BESFile ready for writing
        """
        bes_file = BESFile(filepath=self.filepath)

        # Create header
        bes_file.header = BESHeader(
            signature=BES_MAGIC,
            version='0008',
            exporter=EXPORTER_BLENDER,
            reserved=0,
        )

        # Create preview (placeholder - could be rendered)
        bes_file.preview = BESPreview()
        if self.options.get('generate_preview', True):
            bes_file.preview.pixels = self._generate_preview()

        # Add materials
        bes_file.materials = self._materials

        # Create root node
        scene_name = os.path.splitext(os.path.basename(self.filepath))[0]
        bes_file.root_node = BESNode(
            name=scene_name,
            name_hash=calculate_name_hash(scene_name),
        )

        # Add objects as children of root
        for obj in self._objects:
            child_node = self._convert_object(obj)
            if child_node:
                child_node.parent = bes_file.root_node
                bes_file.root_node.children.append(child_node)

        # Calculate statistics
        bes_file.total_faces = self._count_faces(bes_file.root_node)

        # Create info
        bes_file.info = BESInfo(
            author='Blender Export',
            comment=f'Exported from Blender {bpy.app.version_string}',
            total_faces=bes_file.total_faces,
        )

        return bes_file

    def _get_export_name(self, obj: bpy.types.Object) -> str:
        """Get the proper export name with prefix restored.

        Args:
            obj: Blender object

        Returns:
            Object name with proper prefix for BES export
        """
        name = obj.name

        # Check if we have stored prefix from import
        original_prefix = obj.get('bes_original_prefix', '')
        if original_prefix and not name.startswith(original_prefix):
            return original_prefix + name

        # Check collision type and reconstruct prefix
        obj_type = obj.get('bes_object_type', 'normal')

        if obj_type == 'player' and not name.startswith('^K'):
            return '^K' + name
        elif obj_type == 'bullets' and not name.startswith('^SF'):
            return '^SF' + name
        elif obj_type == 'sphere' and not name.startswith('^SK'):
            return '^SK' + name
        elif obj_type == 'auxiliary' and not name.startswith('!'):
            return '!' + name
        elif obj_type == 'effect':
            # Reconstruct effect sphere name
            if not name.startswith('@'):
                mat = obj.get('bes_effect_material', '')
                slowdown = obj.get('bes_effect_slowdown', 0)
                if mat:
                    return f'@{mat}{slowdown}-{name}'
                return '@' + name
        elif obj_type == 'lod_hidden':
            # Reconstruct LOD prefix
            lod_level = obj.get('bes_lod_level', 1)
            prefix = '>' * lod_level
            if not name.startswith('>'):
                return prefix + name

        return name

    def _convert_object(self, obj: bpy.types.Object) -> Optional[BESNode]:
        """Convert Blender object to BES node.

        Args:
            obj: Blender object

        Returns:
            BES node or None
        """
        # Get proper export name with prefix
        export_name = self._get_export_name(obj)

        node = BESNode(
            name=export_name,
            name_hash=calculate_name_hash(export_name),
        )

        # Set transform
        node.transform = BESTransform(
            translation=blender_to_bes_coords(tuple(obj.location)),
            rotation=blender_to_bes_rotation(tuple(obj.rotation_euler)),
            scale=blender_to_bes_scale(tuple(obj.scale)),
        )

        # Convert mesh data
        if obj.type == 'MESH' and obj.data:
            mesh = self._convert_mesh(obj)
            if mesh:
                node.meshes.append(mesh)

                # Calculate bounding sphere
                verts = [v.position for v in mesh.vertices]
                node.bbox_radius = calculate_bounding_sphere_radius(verts)

        # Convert custom properties
        props_text = self._convert_properties(obj)
        if props_text:
            node.properties = BESProperties(raw_text=props_text)

        # Convert children
        for child in obj.children:
            child_node = self._convert_object(child)
            if child_node:
                child_node.parent = node
                node.children.append(child_node)

        return node

    def _convert_mesh(self, obj: bpy.types.Object) -> Optional[BESMesh]:
        """Convert Blender mesh to BES mesh.

        Args:
            obj: Blender mesh object

        Returns:
            BES mesh or None
        """
        # Get evaluated mesh (with modifiers applied)
        depsgraph = self.context.evaluated_depsgraph_get()
        eval_obj = obj.evaluated_get(depsgraph)
        mesh_data = eval_obj.to_mesh()

        if not mesh_data:
            return None

        # Triangulate
        import bmesh
        bm = bmesh.new()
        bm.from_mesh(mesh_data)
        bmesh.ops.triangulate(bm, faces=bm.faces)
        bm.to_mesh(mesh_data)
        bm.free()

        # Get UV layer
        uv_layer = mesh_data.uv_layers.active

        # Determine material index
        mat_index = NO_MATERIAL
        if mesh_data.materials and mesh_data.materials[0]:
            mat = mesh_data.materials[0]
            mat_index = self._material_indices.get(mat, NO_MATERIAL)

        bes_mesh = BESMesh(material_index=mat_index)

        # Convert vertices
        for vert in mesh_data.vertices:
            pos = blender_to_bes_coords(tuple(vert.co))
            normal = blender_to_bes_coords(tuple(vert.normal))

            bes_vert = BESVertex(
                position=pos,
                normal=normal,
                uvs=[],
            )
            bes_mesh.vertices.append(bes_vert)

        # Convert faces and UVs
        mesh_data.calc_loop_triangles()

        for tri in mesh_data.loop_triangles:
            # Add face
            bes_mesh.faces.append(BESFace(
                a=tri.vertices[0],
                b=tri.vertices[1],
                c=tri.vertices[2],
            ))

            # Update vertex UVs from loops
            if uv_layer:
                for i, vert_idx in enumerate(tri.vertices):
                    loop_idx = tri.loops[i]
                    uv = uv_layer.data[loop_idx].uv
                    bes_uv = blender_to_bes_uv(tuple(uv))

                    # Add UV if vertex doesn't have one yet
                    if not bes_mesh.vertices[vert_idx].uvs:
                        bes_mesh.vertices[vert_idx].uvs.append(bes_uv)

        # Clean up
        eval_obj.to_mesh_clear()

        return bes_mesh

    def _convert_properties(self, obj: bpy.types.Object) -> str:
        """Convert object custom properties to INI format.

        Args:
            obj: Blender object

        Returns:
            INI format string
        """
        # Internal properties that shouldn't be exported to BES
        INTERNAL_PROPS = {
            'bes_object_type',
            'bes_original_prefix',
            'bes_is_collision',
            'bes_collision_type',
            'bes_collision_name',
            'bes_is_effect_sphere',
            'bes_effect_material',
            'bes_effect_slowdown',
            'bes_is_auxiliary',
            'bes_is_lod',
            'bes_lod_level',
        }

        lines = []

        for key, value in obj.items():
            if key.startswith('bes_') and key not in INTERNAL_PROPS:
                prop_name = key[4:]  # Remove 'bes_' prefix

                # Format value appropriately
                if isinstance(value, bool):
                    lines.append(f'{prop_name}={int(value)}')
                elif isinstance(value, float):
                    lines.append(f'{prop_name}={value:.6f}')
                else:
                    lines.append(f'{prop_name}={value}')

        return '\n'.join(lines)

    def _count_faces(self, node: BESNode) -> int:
        """Count total faces in node hierarchy.

        Args:
            node: Root node

        Returns:
            Total face count
        """
        count = sum(len(mesh.faces) for mesh in node.meshes)

        for child in node.children:
            count += self._count_faces(child)

        return count

    def _generate_preview(self) -> bytes:
        """Generate 64x64 preview image.

        Returns:
            BGR pixel data (12288 bytes)
        """
        # For now, return empty preview
        # TODO: Render actual preview from viewport
        return b'\x80\x80\x80' * (64 * 64)  # Gray preview
